# Import
import os
import re
import time
import threading
import zipfile
import random
# import io
try:
    from selenium import webdriver
    from selenium import common
    import requests
    import keyboard
except ModuleNotFoundError:
    print("실행에 필요한 패키지가 설치되지 않았습니다.")
    print("PackageInstall.bat 을 실행합니다.")
    input("엔터를 눌러 설치시작 =>")
    print("Opening . . .")
    os.system("start PackageInstall.bat")
    time.sleep(5)
    input("설치가 완료되었다면 엔터를 눌러주세요. 설치 전에 누르시면 프로그램이 종료됩니다.")
    from selenium import webdriver
    import requests
    import keyboard

# Declaring Area
VERSION = 3.0
FAST_LOAD_OPTION = False
driver = None
User_Data = ['', '', '', 2, "manual", "manual"] # Default Values
progress_bar_load = False

# Defining Area

def menu(m):

        selected_menu = ''
        while (selected_menu!='6'):
            if (m): # 메뉴 진입을 눌렀을 시
                print("\n\n--------MENU--------\n")
                print("0 : 수강완료 처리명령 발송(완전 수동모드)")
                print("1 : 자동수강 시작(로그인 및 진입 자동화, 수강처리 수동모드)")
                print("2 : ID/PW 수정")
                print("3 : 자동수강 관련 설정")
                print("4 : 업데이트 확인")
                print("5 : 메모리 정리")
                print("6 : 프로그램 정보\n")

                selected_menu = input("원하는 명령의 번호를 쓰세요 : ")
                while (not bool(re.search("[0-6]",selected_menu)) and not selected_menu=="crypt"):
                    print("잘못된 입력입니다.")
                    selected_menu = input("원하는 명령의 번호를 쓰세요 : ")
                if (selected_menu == '0'):
                    change_js_variable__totlaLrnTime()
                elif (selected_menu == '1'):
                    print("자동수강을 시작합니다. 자동수강을 끝내려면 브라우저를 닫으시면 됩니다.")
                    load_user_data()
                    try:
                        automatic_lecture_taking__login()
                        input("자동 수강이 끝났습니다. 엔터를 누르면 메뉴로 돌아갑니다.")
                    except common.exceptions.WebDriverException:
                        print("사용자가 창을 닫았거나 WebDriver 가 브라우저를 인식하지 못했습니다.")
                    except Exception and common.exceptions :
                        print("예기치 못한 오류가 발생하였습니다.")
                elif (selected_menu == '2'):
                    edit_user_data()
                    edit_atdat()
                elif (selected_menu == '3'):
                    edit_driver_setting()
                    edit_atdat()
                elif (selected_menu == '4'):
                    check_update()
                elif (selected_menu == '5'):
                    clean_memory()
                elif (selected_menu == '6'):
                    program_info()
                elif (selected_menu == 'crypt'):
                    code = input("CODE : ")
                    mode = input("MODE : ")
                    print(f"Result : {crypt(code, mode)}")
            else: # 1번 자동실행
                load_user_data()
                automatic_lecture_taking__login()
            selected_menu = 0
            m = True

def automatic_lecture_taking__login():
    print("Starting WebDriver . . .")
    if not (os.path.isfile("./WebDriver.exe")):
        print("웹 드라이버가 설치되지 않았거나 지정된 경로에 없습니다. 드라이버 다운로드를 시작합니다.")
        download_file("https://firebasestorage.googleapis.com/v0/b/icpa-9312f.appspot.com/o/chromedriver.exe?alt=media&token=461733c4-57de-438d-bad0-92cc3d99e7d9", "WebDriver.exe")

    print("Attaching WebDriver.exe . . .")
    print("[주의] 프로그램을 강제종료시키면 WebDriver.exe 가 메모리에 남아 메모리 누수가 일어납니다.")
    print("사용 후 프로그램 내 메모리 정리 기능을 꼭 사용하세요.")
    print("개발자가 아직 EBS 사이트 구조를 분석하고 있습니다. 수동모드로 진행됩니다.")
    print("EBS 수업 방식이 아닌 개발자를 이해해주세요...")
    global driver
    driver = webdriver.Chrome("./WebDriver.exe")
    driver.maximize_window()
    print("Connecting to EBS Login page . . .")
    driver.get(User_Data[2])
    time.sleep(User_Data[3])
    driver.find_element_by_xpath("//*[@id=\"header\"]/div[1]/div/div/div/a/img").click()
    time.sleep(User_Data[3])
    driver.find_element_by_xpath("//*[@id=\"header\"]/div[1]/div/div/div/div/ul/li[1]/a").click()
    # driver.get("https://hoc8.ebssw.kr/sso/loginView.do?loginType=onlineClass")
    print("Login . . .")
    driver.find_element_by_name("j_username").send_keys(User_Data[0])
    driver.find_element_by_name("j_password").send_keys(User_Data[1])
    driver.find_element_by_xpath("//*[@id=\"loginViewForm\"]/div/div[1]/fieldset/div/button").click()
    time.sleep(User_Data[3])
    driver.find_element_by_xpath("//*[@id=\"header\"]/div[1]/div/div/div/a/img").click()
    driver.find_element_by_xpath("//*[@id=\"header\"]/div[1]/div/div/div/a/img").click()
    driver.find_element_by_xpath("//*[@id=\"header\"]/div[1]/div/div/div/a/img").click()
    time.sleep(User_Data[3])
    driver.find_element_by_xpath("//*[@id=\"header\"]/div[1]/div/div/div/div/ul/li[1]/a").click()
    time.sleep(User_Data[3])
    loop_time = 5
    while(loop_time >= 1):
        try:
            driver.find_element_by_xpath("//*[@id=\"mainContent\"]/div[1]/div[2]/div[2]/div/dl[2]/dd/ul/li[1]/a").click()
            break
        except: # May occur selenium's No Element Exception
            time.sleep(2)
            driver.find_element_by_xpath("//*[@id=\"mainContent\"]/div[1]/div[2]/div[2]/div/dl[2]/dd/ul/li[1]/a").click()
            print(f"Re-trying to click button . . .     Left Loop : {loop_time}")
        loop_time-=1
    else:
        print("Failed to access element. The reason may be that the internet connection status is bad.")
        print("엘리먼트 접근에 실패하였습니다. 인터넷 상태가 좋지 않기 때문일 수 있습니다.")
        return
#     automatic_lecture_taking__class()
#
# def automatic_lecture_taking__class(): #나중에 나올 기능 생각해서 별도로 분리할 예정
#     global driver
    print("Analyzing the number of lecture . . .")
    the_number_of_class = 0
    while True:
        try:
            driver.find_element_by_xpath(f"//*[@id=\"list_table\"]/div/ul/li[{the_number_of_class+1}]")
            the_number_of_class += 1
        except:
            print(f"확인된 교실(과목) 개수 : {the_number_of_class}")
            break
    if (the_number_of_class == 0):
        print("발견된 교실(과목)이 0개입니다. 자동수강을 진행할 수 없습니다.")
        return
    for i in range(1, the_number_of_class + 1):
        driver.find_element_by_xpath(f"//*[@id=\"list_table\"]/div/ul/li[{i}]").click()
        print(f"{i} 번째 강의 수강 진행중 . . .")
        time.sleep(User_Data[3])
        try:
            driver.execute_script("javascript:showLrnWindow();")
        except: # 킹치만 너무 귀찮았어요 ㅎㅎ;; 이거 정확하게 하려면 테스트를 몇 번이나 해야하는듸...
            try:
                driver.find_element_by_xpath("//*[@id=\"mainContent\"]/div[3]/div[1]/div[1]/div/div/div[2]/a")
                print("수강신청이 되지 않은 강의이므로 건너뜁니다.")
                driver.back()
                pass
            except:
                print("이어하기 버튼이 없습니다. OT 정도는 들으셔야죠! OT도 듣지 않은 인간의 강의는 들어주지 않습니다. (오디서 꼼수를 부리려고!)")
                print("사용자분께서 그렇게 꼼수 부리시면 학부모님들 저한테 달려오십니다... 그러지 마세요 ㄷㄷ")
        driver.switch_to.window(driver.window_handles[1])
        # the_number_of_lecture = 0
        # while True:
        #     try:
        #         driver.find_element_by_xpath(f"//*[@id=\"list_table\"]/div/ul/li[{the_number_of_lecture + 1}]")
            #     the_number_of_lecture += 1
            # except:
            #     print(f"확인된 강의 개수 : {the_number_of_lecture}")
            #     break
        # if (the_number_of_lecture == 0):
        #     print("발견된 강의가 0개입니다. 현재 교실(과목)에서 자동수강을 진행할 수 없습니다.")
        #     break
        driver.execute_script("javascript:alert(\"확인버튼을 누른 후 파이썬 창에서 강의수강을 진행하세요\n-AELT 제작자\")")
        print("왼쪽 사이드바에서 원하는 강의를 선택한 후 원하는 강의를 모두 들었고, 다음 교실(과목)으로 넘어가려면 end 를 쓰세요")
        while True:
            if (input("\n강의 수강 완료 명령을 보내려면 엔터를 치세요. [Enter 키/end] : ").lower() != "end"):
                change_js_variable__totlaLrnTime()
            else:
                break
        driver.execute_script("javascript:goLctrum();")
        print("다음 강의로 넘어갑니다.")
        driver.switch_to.window(driver.window_handles[0])
        time.sleep(User_Data[3])
        driver.back()
        time.sleep(User_Data[3])
        pass # For readability

def change_js_variable__totlaLrnTime():
    random_time = random.randrange(3600, 4500)
    driver.execute_script(script=f"totalLrnTime = {random_time}")
    print("명령을 성공적으로 보냈습니다.")

def load_user_data():
    try:
        print("\n\nFinding UserDataFile . . .")
        global User_Data
        User_Data = [] # Initializing variable
        temp = open("UserData.atdat", 'r').read()
        # if (bool(re.search("[가-힝]", temp))):
        #     raise FileNotFoundError
        temp = temp.split('\n')
        if (len(temp) == 7): # 맨 뒤에 엔터 하나 들어감
            for i in temp:
                print(i)
                User_Data.append(i)
            User_Data[3] = int(User_Data[3])
            print(f"Success. Current UserID : {User_Data[0]}")
        else:
            raise FileNotFoundError

    except FileNotFoundError:
        print("Program cannot find Saved User Data or File may have been damaged.")
        edit_user_data()
        edit_driver_setting()
        edit_atdat()

def edit_user_data():
    global User_Data
    User_Data[0] = input("Please enter your EBS Account ID : ")
    User_Data[1] = input("Please enter your EBS Account PASSWORD : ")
    print("이제 학교 페이지를 입력하셔야 합니다. 학교페이지란, EBS 온라인 클래스에서 지역 선택을 하고 초·중·고 선택을 하여 나온 자신의 학교를 클릭하면 나오는 페이지 입니다.")
    print("[주의] 제대로 입력하지 않을 경우 프로그램이 작동하지 않을 수 있습니다!")
    User_Data[2] = input("Please enter your school page URL in EBS Online Class : ")
    print("EBS 사이트 ID/PW 및 학교 페이지가 UserData.atdat 파일에 저장됩니다. 파일에 암호화되지 않은 상태로 정보가 들어가니 파일관리에 주의하시기 바랍니다.")
    print("[주의] 파일이 프로그램과 동일한 위치에 있어야 프로그램이 인식할 수 있습니다. 파일 안 내용을 수정하시게 되면 파일 분석 시 오류가 나니 정부 수정은 프로그램 내에서 하시기 바랍니다.")

def edit_driver_setting():
    print("웹페이지 동적반응 대기시간과 퀴즈·서술형 에 대한 대답을 세팅합니다.")
    global User_Data
    try:
        User_Data[3] = input("페이지 동적반응 대기시간(JS 애니메이션 대기시간, 컴퓨터의 사양에 맞게 조절하며 기본값은 2(초)) [숫자]초 : ")
    except TypeError:
        print("숫자 이외의 문자를 입력하여 기본값인 2초로 설정딥니다.")
    User_Data[4] = input("토론형 질문에 대한 답변 설정, 수동 입력을 원하면 manual 입력(수동입력 설정 시 프로그램이 입력칸에서 멈춥니다.) ['원하는 문구'/manual] : ")
    User_Data[5] = "manual" if input("퀴즈형 자동선택과 수동선택 설정 [random/manual] : ").lower() == "manual" else "random"

def edit_atdat():
    User_Data[3] = str(User_Data[3])
    UIF = open("UserData.atdat", 'w')
    for i in User_Data:
        UIF.write(i + '\n')
    UIF.close()
    User_Data[3] = int(User_Data[3])
    print("Save Completed")

def check_update():
    print("Loading Release Data . . .")
    html = requests.get("http://rss.blog.naver.com/leo2316").text.split("*PFH[UNIQUE^#^^]*")[1].split("*/PFH[UNIQUE^#^^]*")[0]
    print("Decoding information . . .")
    url = crypt(html, "-1")
    download_file(url,"release_info.atdat")
    print("Checking release_info.atdat . . .")
    release_info = open("release_info.atdat", 'rt', encoding="UTF8").read().split("^VER^")
    release_info.pop(0)
    version = []
    comment = []
    url = []
    for pver in release_info:
        version.append(pver.split("^/VER^")[0])
        comment.append(pver.split("#DEVcomments#")[1].split("#/DEVcomments#")[0])
        url.append(pver.split("^#>>")[1])
    os.remove("release_info.atdat")
    print("\n\n\n=======|RELEASE INFO|===========================================================")
    # print("================================================================================")
    for i in range(len(version)):
        print("#", version[i])
        print( comment[i], "" if i==len(version)-1 else("\n---------------------------------------------------------------------"))
    print("================================================================================")
    print("[주의] *표시가 된 버전은 현재 버전과 업그레이드 메서드가 호환되지 않는 버전입니다. 해당 버전으로 다운그레이드 시 다시 자동 업그레이드 할 수 없습니다.")
    print(" * 으로 다운그레이드한 경우 상위버전으로 프로그램을 직접 다시 받으셔야 합니다.")
    try:
        index = version.index(input("업그레이드할 버전을 숫자로 써주세요.(*포함) 유효하지 않은 값을 입력하면 취소됩니다. : "))
        if (version[index] == str(VERSION)):
            print("동일한 버전을 사용중입니다.")
            return
    except ValueError or TypeError as e:
        print(e)
        print("업그레이드 취소됨.")
        return
    name = f"AELT {version[index]}.zip".replace("*","")
    try:
        os.remove("PackageInstall.bat")
    except FileNotFoundError:
        pass
    # print(url[index])
    download_file(url[index], name)
    print("Uncompress files . . .")
    try:
        with zipfile.ZipFile(name) as zf:
            zf. extractall()
            print("Success")
    except Exception as e:
        print("Failed to uncompress : ", e)
    print("Cleaning . . .")
    try:
        os.remove(name)
    except FileNotFoundError or Exception:
        print("Failed to remove ", name)
    print("업데이트를 완료하였습니다. 프로그램이 종료된 후 신버전 파일을 실행시켜주시기 바랍니다.")
    print("아무키나 누르면 종료됩니다.")
    keyboard.read_event()
    exit()

def clean_memory():
    if (input("메모리 정리 시 현재 실행중인 자동 동작 창이 닫힙니다. 정리하시겠습니까? [Y/N]").upper() == "Y"):
        print("Closing window and killing WebDriver.exe . . .")
        try:
            global driver
            driver.close()
        except:
            print("열린 창 없음.")
        try:
            os.system("taskkill /im WebDriver.exe /t /f")
            print("Driver 프로세스를 모두 정리하였습니다.")
        except Exception as e:
            print(e)
            print("Driver 프로세스의 종료에 실패했습니다. 명령이 거부되었을 수 있습니다.")
            print("CMD 에 taskkill /im WebDriver.exe /t /f 명령을 입력하시면 해결하실 수 있습니다.")

def program_info():
    # Comments
    print(f"\n\n\nAutomatic EBS Lecture Taking Program      Version : {VERSION}\nMade by ForestHouse.     FeedBack Blog : https://blog.naver.com/leo2316")
    print("This program DO NOT collect any personal information. This is OPEN-SOURCE Project. If you have any problem, please feedback in blog by comment.")
    print("이 프로그램은 사용자의 개인정보를 수집하지 않으며 오픈소스 형태로 제작됩니다. 사용시 생기는 문제는 블로그에 댓글로 피드백을 남겨주시기 바랍니다.")
    print("*--------------------------------------------------------------------------------------*")
    print("[Notice] Developer is not responsible for abuse.")
    print("This is for students who have prepared so don't have to take EBS classes.")
    print("I highly recommend that you listen to the lecture, regardless of whether you have prepared.")
    # print("This program developed based on EBS HighSchool page.")
    # print("So I cannot guarantee about compatibly about MiddleSchool page.")
    print("\n[경고] 개발자는 해당 프로그램을 악용하는 것과 학업에 지장이 생기는 것에 대해 책임지지 않습니다.")
    print("이 프로그램은 예습을 하여 EBS수강이 필요하지 않은 학생들을 위한 프로그램입니다.")
    print("교육부의 지침에 따라 예습과 관계없이 되도록이면 강의를 들으시는 것을 강력히 권장합니다.")
    print("본 프로그램은 고등학교 페이지 기준으로 만들어졌습니다.")
    print("그러므로 중학교 페이지와의 호환성을 보장하지 않습니다. 하지만 호환될 것으로 예상합니다.")
    print("터미널 환경에서 UI와 exit()이 정상적으로 수행되지 않을 수 있습니다. Shell(IDLE)에서의 사용을 권장합니다.")
    print("*--------------------------------------------------------------------------------------*")
    time.sleep(1)



# ---------------------------------------

def dot_progress_bar(repeat, delay):
    global progress_bar_load
    for i in range(repeat, 0, -1):
        if (progress_bar_load == False):
            break
        print(". ", end='')
        time.sleep(delay)
    progress_bar_load = False

def crypt(code, mode): #내가 이런 조잡한 암호화를 하는 이유는 간단하게라도 인간들 이상한 테러 못하게 하려고 그러는거임.
    table = {
        'a': '#a^a',
        'b': 'BAE)D',
        'c': '18^^1',
        'd': 'DDO#',
        'e': '^Ee^',
        'f': 'f###',
        '-' : "-^FH^-",
        '/': "^#^^",
        '.': "TOD"
    }
    if (mode == "1"):
        for original, encrypted in table.items():
            code = code.replace(original, encrypted)
    elif (mode == "-1"):
        table['&'] = "&amp;"
        table['='] = "&#x3D;"
        for original, encrypted in table.items():
            code = code.replace(encrypted, original)
    return code

def download_file(url, name):
    # header = {"User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.92 Safari/537.36"}
    with open(name, 'wb') as file: # wb = Write in BinaryMode
        response = requests.get(url).content
        file.write(response)
    print(f"{name} 파일을 다운로드 하였습니다.")

# Start
program_info()
print("\n\n설정 메뉴에 진입하려면 3초 이내에 M 키를 누르세요")
t1 = threading.Thread(target=dot_progress_bar, args=(10, 0.3))
t1.Daemon = True
progress_bar_load = True
t1.start()
while (progress_bar_load):
    if (keyboard.is_pressed("m")):
        time.sleep(0.05)
        progress_bar_load = False
        keyboard.press_and_release('\b')
        menu(True)
        break
else:
    print("\n\n\n\n\n")
    menu(False)
