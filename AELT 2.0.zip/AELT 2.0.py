# Import
import os
import re
import time
import threading
import zipfile
import io

try:
    from selenium import webdriver
    import requests
    import keyboard
except ModuleNotFoundError:
    print("실행에 필요한 패키지가 설치되지 않았습니다.")
    print("PackageInstall.bat 을 실행합니다.")
    input("엔터를 눌러 설치시작 =>")
    print("Opening . . .")
    os.system("start PackageInstall.bat")
    time.sleep(5)
    input("설치가 완료되었다면 엔터를 눌러주세요. 설치 전에 누르시면 프로그램이 종료됩니다.")
    from selenium import webdriver
    import requests
    import keyboard

# Declaring Area
VERSION = 2.0
FAST_LOAD_OPTION = False
driver = webdriver # selenium 미리 참조
User_Data = []
progress_bar_load = False
PAGE_LOAD_TERM = 2

# Defining Area

def menu(m):

        selected_menu = ''
        while (selected_menu!='6'):
            if (m): # 메뉴 진입을 눌렀을 시
                print("\n\n--------MENU--------\n")
                print("1 : 자동수강 시작")
                print("2 : ID/PW 수정")
                print("3 : 업데이트 확인")
                print("4 : ----------")
                print("5 : 프로그램 정보")
                print("6 : 프로그램 종료\n")
                selected_menu = input("원하는 명령의 번호를 쓰세요 : ")
                while (not bool(re.search("[1-6]",selected_menu)) and not selected_menu=="crypt"):
                    print("잘못된 입력입니다.")
                    selected_menu = input("원하는 명령의 번호를 쓰세요 : ")
                if (selected_menu == '1'):
                    print("자동수강을 시작합니다. 자동수강을 끝내려면 ")
                    load_user_data()
                    automatic_lecture_taking()
                    input("자동 수강이 끝났습니다. 엔터를 누르면 메뉴로 돌아갑니다.")
                elif (selected_menu == '2'):
                    edit_user_data()
                elif (selected_menu == '3'):
                    check_update()
                elif (selected_menu == '4'):
                    print("빠진 기능입니다. 추후 다른 기능이 추가될 예정입니다.")
                    print(" + 피드백을 주셔야 뭐가 문제인지 알 수 있습니다. 블로그에 댓글로 피드백해주세요 :)")
                elif (selected_menu == '5'):
                    program_info()
                elif (selected_menu == '6'):
                    exit_program()
                elif (selected_menu == 'crypt'):
                    code = input("CODE : ")
                    mode = input("MODE : ")
                    print(f"Result : {crypt(code, mode)}")
            else: # 1번 자동실행
                load_user_data()
                automatic_lecture_taking()
            selected_menu = 0
            m = True

def automatic_lecture_taking():
    print("Starting WebDriver . . .")
    if not (os.path.isfile("./WebDriver.exe")):
        print("웹 드라이버가 설치되지 않았거나 지정된 경로에 없습니다. 드라이버 다운로드를 시작합니다.")
        download_file("https://firebasestorage.googleapis.com/v0/b/icpa-9312f.appspot.com/o/chromedriver.exe?alt=media&token=461733c4-57de-438d-bad0-92cc3d99e7d9", "WebDriver.exe")

    print("Attaching WebDriver.exe . . .")
    print("[주의] 프로그램을 강제종료시키면 WebDriver.exe 가 메모리에 남아 메모리 누수가 일어납니다.")
    print("종료 시 정상적인 방법으로 종료해주시기 바랍니다.")
    global driver
    driver = webdriver.Chrome("./WebDriver.exe")
    driver.maximize_window()
    print("Connecting to EBS Login page . . .")
    driver.get(User_Data[2])
    time.sleep(PAGE_LOAD_TERM)
    driver.find_element_by_xpath("//*[@id=\"header\"]/div[1]/div/div/div/a/img").click()
    time.sleep(PAGE_LOAD_TERM)
    driver.find_element_by_xpath("//*[@id=\"header\"]/div[1]/div/div/div/div/ul/li[1]/a").click()
    # driver.get("https://hoc8.ebssw.kr/sso/loginView.do?loginType=onlineClass")
    print("Login . . .")
    driver.find_element_by_name("j_username").send_keys(User_Data[0])
    driver.find_element_by_name("j_password").send_keys(User_Data[1])
    driver.find_element_by_xpath("//*[@id=\"loginViewForm\"]/div/div[1]/fieldset/div/button").click()
    time.sleep(PAGE_LOAD_TERM)
    driver.find_element_by_xpath("//*[@id=\"header\"]/div[1]/div/div/div/a/img").click()
    driver.find_element_by_xpath("//*[@id=\"header\"]/div[1]/div/div/div/a/img").click()
    driver.find_element_by_xpath("//*[@id=\"header\"]/div[1]/div/div/div/a/img").click()
    time.sleep(PAGE_LOAD_TERM)
    driver.find_element_by_xpath("//*[@id=\"header\"]/div[1]/div/div/div/div/ul/li[1]/a").click()
    time.sleep(PAGE_LOAD_TERM)
    loop_time = 5
    while(loop_time >= 1):
        try:
            driver.find_element_by_xpath("//*[@id=\"mainContent\"]/div[1]/div[2]/div[2]/div/dl[2]/dd/ul/li[1]/a").click()
            break
        except: # May occur selenium's No Element Exception
            time.sleep(2)
            driver.find_element_by_xpath("//*[@id=\"mainContent\"]/div[1]/div[2]/div[2]/div/dl[2]/dd/ul/li[1]/a").click()
            print(f"Re-trying to click button . . .     Left Loop : {loop_time}")
        loop_time-=1
    else:
        print("Failed to access element. The reason may be that the internet connection status is bad.")
        print("엘리먼트 접근에 실패하였습니다. 인터넷 상태가 좋지 않기 때문일 수 있습니다.")
        return
    print("Analyzing the number of lecture . . .")

def load_user_data():
    try:
        print("\n\nFinding UserDataFile . . .")
        global User_Data
        temp = open("UserData.atdat", 'r').read()
        if (bool(re.search("[가-힝]", temp))):
            raise FileNotFoundError
        temp = temp.split('\n')
        for i in temp:
            print(i)
            User_Data.append(i)

        print(f"Success. Current UserID : {User_Data[0]}")

    except FileNotFoundError:
        print("Program cannot find Saved User Data or File may have been damaged.")
        edit_user_data()

def edit_user_data():
    # User_Data : 0=ID 1=PW 2=SchoolURL
    global User_Data
    User_Data = [input("Please enter your EBS Account ID : "), input("Please enter your EBS Account PASSWORD : "), input("Please enter your Schoolpage URL in EBS : ")]
    if (input("Do you want to save this information? [Y/N] : ").upper() == "Y"):
        print("EBS 사이트 ID/PW가 UserData.atdat 파일에 저장됩니다. 파일에 암호화되지 않은 상태로 정보가 들어가니 파일관리에 주의하시기 바랍니다.")
        print("파일이 프로그램과 동일한 위치에 있어야 프로그램이 인식할 수 있습니다.")
        UIF = open("UserData.atdat", 'w')
        for i in User_Data:
            if (bool(re.search("[가-힝]", i))):
                print("한글은 포함될 수 없습니다. 수정이 취소됩니다.")
                time.sleep(1)
                break
            UIF.write(i+'\n')
        UIF.close()
        print("Save Completed")

def check_update():
    print("Loading Release Data . . .")
    html = requests.get("http://rss.blog.naver.com/leo2316").text.split("*PFH[UNIQUE^#^^]*")[1].split("*/PFH[UNIQUE^#^^]*")[0]
    print("Decoding information . . .")
    url = crypt(html, "-1")
    print(url)
    download_file(url,"release_info.atdat")
    print("Checking release_info.atdat . . .")
    release_info = open("release_info.atdat", 'rt', encoding="UTF8").read().split("^VER^")
    release_info.pop(0)
    print ("Release : ", release_info)
    version = []
    comment = []
    url = []
    for pver in release_info:
        print ("PVERPVER", pver)
        version.append(pver.split("^/VER^")[0])
        comment.append(pver.split("#DEVcomments#")[1].split("#/DEVcomments#")[0])
        url.append(pver.split("^#>>")[1])
    os.remove("release_info.atdat")
    print("\n\n\n================================================================================")
    for i in range(len(version)):
        print("#", version[i])
        print( comment[i], "" if i==len(version)-1 else("\n---------------------------------------------------------------------"))
    print("================================================================================")
    print("[주의] *표시가 된 버전은 현재 버전과 업그레이드 메서드가 호환되지 않는 버전입니다. 해당 버전으로 다운그레이드 시 다시 자동 업그레이드 할 수 없습니다.")
    print(" * 으로 다운그레이드한 경우 상위버전으로 프로그램을 직접 다시 받으셔야 합니다.")
    try:
        index = version.index(input("업그레이드할 버전을 숫자로 써주세요.(*포함) 유효하지 않은 값을 입력하면 취소됩니다. : "))
        if (version[index] == str(VERSION)):
            print("동일한 버전을 사용중입니다.")
            return
    except ValueError or TypeError as e:
        print(e)
        print("업그레이드 취소됨.")
        return
    name = f"AELT {version[index]}.zip".replace("*","")
    try:
        os.remove("PackageInstall.bat")
    except FileNotFoundError:
        pass
    print(url[index])
    download_file("https://firebasestorage.googleapis.com/v0/b/icpa-9312f.appspot.com/o/AELT%201.0.zip?alt=media&token=85391b90-7daf-4422-bfc9-fc91e9667def", name)
    print("Uncompress files . . .")
    try:
        with zipfile.ZipFile(name) as zf:
            zf. extractall()
            print("Cleaning . . .")
            try:
                os.remove(name)
            except FileNotFoundError or Exception:
                print("Failed to remove ",name)
            print("Success")
            print("업데이트를 완료하였습니다. 프로그램이 종료된 후 신버전 파일을 실행시켜주시기 바랍니다.")
            print("아무키나 누르면 종료됩니다.")
            keyboard.read_event()
            exit()
    except Exception as e:
        print("Failed to uncompress : ", e)

def program_info():
    # Comments
    print(f"\n\n\nAutomatic EBS Lecture Taking Program      Version : {VERSION}\nMade by ForestHouse.     FeedBack Blog : https://blog.naver.com/leo2316")
    print("This program DO NOT collect any personal information. This is OPEN-SOURCE Project. If you have any problem, please feedback in blog by comment.")
    print("이 프로그램은 사용자의 개인정보를 수집하지 않으며 오픈소스 형태로 제작됩니다. 사용시 생기는 문제는 블로그에 댓글로 피드백을 남겨주시기 바랍니다.")
    print("*--------------------------------------------------------------------------------------*")
    print("[Notice] Developer is not responsible for abuse.")
    print("This is for students who have prepared so don't have to take EBS classes.")
    print("I highly recommend that you listen to the lecture, regardless of whether you have prepared.")
    print("This program developed based on EBS HighSchool page.")
    print("So I cannot guarantee about compatibly about MiddleSchool page.")
    print("\n[경고] 개발자는 해당 프로그램을 악용하는 것과 학업에 지장이 생기는 것에 대해 책임지지 않습니다.")
    print("이 프로그램은 예습을 하여 EBS수강이 필요하지 않은 학생들을 위한 프로그램입니다.")
    print("교육부의 지침에 따라 예습과 관계없이 되도록이면 강의를 들으시는 것을 강력히 권장합니다.")
    print("본 프로그램은 고등학교 페이지 기준으로 만들어졌습니다.")
    print("그러므로 중학교 페이지와의 호환성을 보장하지 않습니다. 하지만 호환될 것으로 예상합니다.")
    print("*--------------------------------------------------------------------------------------*")
    time.sleep(1)

def exit_program():
    print("Closing window and killing WebDriver.exe . . .")
    try:
        global driver
        driver.close()
        os.system("taskkill /im WebDriver.exe /t /f")
    except:
        pass
    exit()

# ---------------------------------------

def dot_progress_bar(repeat, delay):
    global progress_bar_load
    for i in range(repeat, 0, -1):
        if (progress_bar_load == False):
            break
        print(". ", end='')
        time.sleep(delay)
    progress_bar_load = False

def crypt(code, mode): #내가 이런 조잡한 암호화를 하는 이유는 간단하게라도 인간들 이상한 테러 못하게 하려고 그러는거임.
    table = {
        'a': '#a^a',
        'b': 'BAE)D',
        'c': '18^^1',
        'd': 'DDO#',
        'e': '^Ee^',
        'f': 'f###',
        '-' : "-^FH^-",
        '/': "^#^^",
        '.': "TOD"
    }
    if (mode == "1"):
        for original, encrypted in table.items():
            code = code.replace(original, encrypted)
    elif (mode == "-1"):
        table['&'] = "&amp;"
        table['='] = "&#x3D;"
        for original, encrypted in table.items():
            code = code.replace(encrypted, original)
    return code

def download_file(url, name):
    # header = {"User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.92 Safari/537.36"}
    with open(name, 'wb') as file: # wb = Write in BinaryMode
        response = requests.get(url).content
        file.write(response)
    print(f"{name} 파일을 다운로드 하였습니다.")

# Start
program_info()
print("\n\n설정 메뉴에 진입하려면 3초 이내에 M 키를 누르세요")
t1 = threading.Thread(target=dot_progress_bar, args=(10, 0.3))
t1.Daemon = True
progress_bar_load = True
t1.start()
while (progress_bar_load):
    if (keyboard.is_pressed("m")):
        time.sleep(0.05)
        progress_bar_load = False
        menu(True)
        break
else:
    print("\n\n\n\n\n")
    menu(False)
